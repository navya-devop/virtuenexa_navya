from stock_monitor import fetch_stock_price
import logging

logging.basicConfig(level=logging.INFO)

def main():
    print("=== Stock Monitor ===")
    symbol = input("Enter stock symbol (e.g., AAPL): ").upper()
    try:
        price = fetch_stock_price(symbol)
        print(f"{symbol} current price: ${price:.2f}")
        logging.info(f"Fetched price for {symbol}: ${price:.2f}")
    except ValueError as e:
        print(e)
        logging.error(e)

if __name__ == "__main__":
    main()