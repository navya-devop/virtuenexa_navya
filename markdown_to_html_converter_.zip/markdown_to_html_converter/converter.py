import os
from markdown import markdown
from utils.file_handler import read_markdown_file, save_html_file, log_conversion
from utils.history import init_db, log_to_db, export_history_to_csv

def main():
    init_db()
    print("Markdown to HTML Converter")
    filepath = input("Enter the path to your .md file: ").strip()

    if not filepath.endswith(".md"):
        print("Error: Please provide a valid .md file.")
        return

    if not os.path.exists(filepath):
        print("Error: File does not exist.")
        return

    content = read_markdown_file(filepath)
    if content.strip() == "":
        print("Warning: Markdown file is empty.")
        return

    html_content = markdown(content)
    output_path = save_html_file(filepath, html_content)

    if output_path:
        print(f"HTML file saved to: {output_path}")
        log_conversion(filepath, output_path)
        log_to_db(filepath, output_path)
    else:
        print("Error saving HTML file.")

if __name__ == "__main__":
    main()
