def calculate(expression):
    try:
        result = eval(expression, {"__builtins__": None}, {})
        return result
    except ZeroDivisionError:
        raise ValueError("Cannot divide by zero.")
    except Exception:
        raise ValueError("Invalid expression.")