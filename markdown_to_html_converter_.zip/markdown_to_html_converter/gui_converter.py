import os
import tkinter as tk
from tkinter import filedialog, messagebox
from markdown import markdown
from utils.file_handler import read_markdown_file, save_html_file, log_conversion
from utils.history import init_db, log_to_db

def convert_file():
    filepath = filedialog.askopenfilename(filetypes=[("Markdown files", "*.md")])
    if not filepath:
        return

    content = read_markdown_file(filepath)
    if content.strip() == "":
        messagebox.showwarning("Empty File", "The selected markdown file is empty.")
        return

    html_content = markdown(content)
    output_path = save_html_file(filepath, html_content)

    if output_path:
        messagebox.showinfo("Success", f"HTML file saved: {output_path}")
        log_conversion(filepath, output_path)
        log_to_db(filepath, output_path)
    else:
        messagebox.showerror("Error", "Failed to save HTML file.")

def launch_gui():
    init_db()
    root = tk.Tk()
    root.title("Markdown to HTML Converter")
    root.geometry("300x150")

    label = tk.Label(root, text="Click below to select a Markdown file:")
    label.pack(pady=10)

    button = tk.Button(root, text="Convert Markdown", command=convert_file)
    button.pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    launch_gui()
