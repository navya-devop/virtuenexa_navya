from cipher import caesar_encrypt, caesar_decrypt
from calculator import calculate
from logger import log_operation

def main():
    while True:
        print("\nChoose an option:")
        print("1. Caesar Cipher Encrypt")
        print("2. Caesar Cipher Decrypt")
        print("3. Calculator")
        print("4. Exit")
        
        choice = input("Enter choice (1-4): ")
        
        if choice == "1":
            text = input("Enter text to encrypt: ")
            key = int(input("Enter shift key (integer): "))
            result = caesar_encrypt(text, key)
            print("Encrypted Text:", result)
            log_operation("Encrypt", text, key, result)

        elif choice == "2":
            text = input("Enter text to decrypt: ")
            key = int(input("Enter shift key (integer): "))
            result = caesar_decrypt(text, key)
            print("Decrypted Text:", result)
            log_operation("Decrypt", text, key, result)

        elif choice == "3":
            expr = input("Enter arithmetic expression (e.g., 4 + 5): ")
            try:
                result = calculate(expr)
                print("Result:", result)
                log_operation("Arithmetic", expr, None, result)
            except Exception as e:
                print("Error:", e)

        elif choice == "4":
            print("Exiting...")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()