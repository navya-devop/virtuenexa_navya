import sqlite3
from datetime import datetime
import pandas as pd
import os

DB_PATH = "markdown_to_html_converter/history.db"

def init_db():
    os.makedirs("markdown_to_html_converter", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS conversion_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            source_file TEXT,
            output_file TEXT
        )
    """)
    conn.commit()
    conn.close()

def log_to_db(source_file, output_file):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO conversion_history (timestamp, source_file, output_file) VALUES (?, ?, ?)",
                   (datetime.now().isoformat(), source_file, output_file))
    conn.commit()
    conn.close()

def export_history_to_csv():
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM conversion_history", conn)
    conn.close()
    csv_path = "markdown_to_html_converter/conversion_report.csv"
    df.to_csv(csv_path, index=False)
    return csv_path
