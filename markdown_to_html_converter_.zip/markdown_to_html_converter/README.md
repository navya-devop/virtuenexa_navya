# Markdown to HTML Converter

This is a Python project to convert Markdown (`.md`) files to HTML.

## Features

- Console-based converter (`converter.py`)
- Optional GUI using Tkinter (`gui_converter.py`)
- Logs all conversions to `logs/converter.log`

## Setup

1. Install required library:
   ```
   pip install markdown
   ```

2. Run the console version:
   ```
   python converter.py
   ```

3. Run the GUI version (optional):
   ```
   python gui_converter.py
   ```

## Project Structure

```
markdown_to_html_converter/
├── converter.py
├── gui_converter.py
├── utils/
│   └── file_handler.py
├── logs/
│   └── converter.log
├── README.md
└── sample.md
```
