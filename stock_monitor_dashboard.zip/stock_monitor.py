import yfinance as yf

def fetch_stock_price(symbol):
    try:
        stock = yf.Ticker(symbol)
        data = stock.history(period='1d')
        if data.empty:
            raise ValueError("No data returned for symbol.")
        current_price = data['Close'].iloc[-1]
        return current_price
    except Exception as e:
        raise ValueError(f"Error fetching stock: {e}")