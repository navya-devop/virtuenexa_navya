import tkinter as tk
from stock_monitor import fetch_stock_price

def get_price():
    symbol = entry.get().upper()
    try:
        price = fetch_stock_price(symbol)
        result_label.config(text=f"Price: ${price:.2f}")
    except:
        result_label.config(text="Error fetching data")

root = tk.Tk()
root.title("Stock Price Monitor")

entry = tk.Entry(root)
entry.pack(pady=5)

btn = tk.Button(root, text="Get Price", command=get_price)
btn.pack(pady=5)

result_label = tk.Label(root, text="")
result_label.pack(pady=10)

root.mainloop()