# Cipher Calculator (Basic Version)

## Features
- Caesar Cipher Encryption/Decryption
- Basic Arithmetic Calculator
- Console-based user interface
- Operation logs written to `report.txt`

## Running the App
Make sure you have Python 3 installed, then run:

```bash
python main.py
```