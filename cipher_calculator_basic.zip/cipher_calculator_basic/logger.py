from datetime import datetime

def log_operation(op_type, input_data, key, result):
    with open("report.txt", "a") as file:
        file.write(f"{datetime.now()} | {op_type} | Input: {input_data} | Key: {key} | Result: {result}\n")