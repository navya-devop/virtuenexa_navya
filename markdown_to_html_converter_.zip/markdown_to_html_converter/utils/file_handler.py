import os
from datetime import datetime

def read_markdown_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as file:
            return file.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return ""

def save_html_file(md_path, html_content):
    try:
        base_name = os.path.splitext(os.path.basename(md_path))[0]
        html_path = os.path.join(os.path.dirname(md_path), f"{base_name}.html")
        with open(html_path, 'w', encoding='utf-8') as file:
            file.write(html_content)
        return html_path
    except Exception as e:
        print(f"Error saving HTML file: {e}")
        return None

def log_conversion(md_path, html_path):
    log_path = "markdown_to_html_converter/logs/converter.log"
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, 'a', encoding='utf-8') as log_file:
        log_file.write(f"[{datetime.now()}] Converted: {md_path} -> {html_path}\n")
