# Sample Markdown

This is a **bold** text and this is *italic*.

- Item 1
- Item 2

[Visit OpenAI](https://openai.com)
