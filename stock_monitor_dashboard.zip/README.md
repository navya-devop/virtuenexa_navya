# Stock Monitor Dashboard

## Overview
A simple real-time stock monitor dashboard using Python CLI and optional GUI.

## Features
- Fetch current stock price using Yahoo Finance
- Console and GUI interface
- Logging of operations

## Setup
```bash
pip install -r requirements.txt
python main.py
# or for GUI
python gui.py
```